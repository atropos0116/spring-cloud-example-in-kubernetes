export API_KEY=AIzaSyCEFbzUDtGNjMVtd6LadiGegLLjy_MHjUM
    cd ~/spring-cloud-example-in-kubernetes
    echo "key = '${API_KEY}'" > api_key.py
