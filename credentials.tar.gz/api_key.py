export API_KEY=AIzaSyAKJ3qO2lXH-GUv4LfMzgtmf7FfMnysqoo
    cd ~/continuous-deployment-demo
    echo "key = '${API_KEY}'" > api_key.py
